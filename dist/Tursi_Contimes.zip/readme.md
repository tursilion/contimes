20020316

Contimes is a utility for a Fuzzball muck that tracks and makes visible to others when a player has been online. Includes privacy option and optional color ANSI (libAnsi or Glow-style) added by Marjan.
